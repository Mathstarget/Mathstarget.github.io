import Main from "@elementSeparator/footer/main";
import Script from "@elementSeparator/footer/script";
export default function Footer(){
    return(
        <>
        <Main />
        <Script />
        </>
    )
}