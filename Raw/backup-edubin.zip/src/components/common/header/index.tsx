import LinkHeader from "@elementSeparator/header/links";
import Search from "@elementSeparator/header/search";
export default function Header() {
    return (
<>
 <LinkHeader />
 <Search />
 </>
)
}