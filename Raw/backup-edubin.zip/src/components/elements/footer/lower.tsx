import Copyrighttxt from "./Copyright";

export default function lowerFooter(){
    return(
        <>
        <div className="footer-copyright pt-10 pb-25">
            <div className="container">
                <div className="row">
                    <Copyrighttxt />
                </div> 
            </div> 
          </div> 
        </>
    )
}