export default function Copyrighttxt(){
    return(
        <>
        <div className="col-md-8">
                        <div className="copyright text-md-left text-center pt-10">
                            <p>&copy; Copyrights 2023 <span>Maths Target Academy</span> </p>
                        </div>
                    </div>
                 {/*   <div className="col-md-4">
                        <div className="copyright text-md-right text-center pt-15">
                            <p>Designed by <span>Pixelcurve</span> </p>
                            <p>Designed by <span>Pixelcurve</span> </p>
                        </div>
    </div> */}
                    
        </>
    )
}