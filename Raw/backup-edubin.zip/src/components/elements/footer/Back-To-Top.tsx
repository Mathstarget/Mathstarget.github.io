export default function Bactotop(){
    return(
        <>
           <a href="#" className="back-to-top"><i className="fa fa-angle-up"></i></a>
        </>
    )
}