import Bactotop from "./Back-To-Top"
import BxFoot from "./upper"
import CxFoot from "./lower"

export default function Main(){
    return(
        <>
    <footer id="footer-part">
    <BxFoot />
    <CxFoot />
    </footer>
    <Bactotop />
        </>
    )
}