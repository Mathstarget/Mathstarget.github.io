export default function FAQs(){
    return(
        <>
        
        </>
    )
    }