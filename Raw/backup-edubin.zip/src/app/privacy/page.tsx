export default function Privacy(){
    return(
        <>
        
        </>
    )
    }