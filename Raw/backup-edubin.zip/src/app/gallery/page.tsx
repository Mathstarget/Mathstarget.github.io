export default function Gallery(){
    return(
        <>
        
        </>
    )
    }